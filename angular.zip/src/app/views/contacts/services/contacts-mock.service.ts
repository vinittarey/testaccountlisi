import { Observable, of } from 'rxjs';
import { Contact } from '@app/core/models';


export class ContactsServiceMock {

  contacts = [{
    id: 1,
    firstname: 'john',
      lastname:'doe',
      email: 'john@gmail.com',
      image:'sample.jpg'
  }, {
    id: 2,
    firstname: 'adam',
      lastname:'son',
      email: 'adam1@gmail.com',
      image:'sample.jpg'
  }];

  index(): Observable<Contact[]> {
   return of(this.contacts);
  }

  show(conactId: number): Observable<Contact> {
    return of({
      id: 1,
      firstname: 'john',
      lastname:'doe',
      email: 'john@gmail.com',
      image:'sample.jpg'
    });
  }

  create(contact: Contact) {
    return of({
      id: 4,
      firstname: 'john',
      lastname:'doe',
      email: 'john@gmail.com',
      image:'sample.jpg'
    });
  }

  destroy(id: number): Observable<number> {
    return of(1);
  }

  update(contact: Contact): Observable<Contact> {
    return of(contact);
  }

}
