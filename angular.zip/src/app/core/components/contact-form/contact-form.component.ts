import {ChangeDetectionStrategy, Component, EventEmitter, Input, OnChanges, OnInit, Output} from '@angular/core';
import { Contact } from '@app/core/models';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';


@Component({
  selector: 'app-contact-form',
  templateUrl: './contact-form.component.html',
  styleUrls: ['./contact-form.component.sass'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ContactFormComponent implements OnInit, OnChanges {

  @Input() contact: Contact = {
    id: undefined,
    firstname: '',
    lastname:'',
    email: '',
    image: ''
  };

  imageValue:any;

  @Output() save = new EventEmitter<Contact>();

  form: FormGroup;

  constructor(public formBuilder: FormBuilder) {
    this.form = this.formBuilder.group({
      id: [this.contact.id],
      firstname: [this.contact.firstname, Validators.required],
      lastname: [this.contact.lastname, Validators.required],
      email: [this.contact.email, Validators.required],
      image: [this.contact.image]
    });
  }

  ngOnInit() {

  }

  ngOnChanges() {
    if (this.contact) {
      this.form.patchValue({...this.contact});
    }
  }

   getBase64(event) {
    let me = this;
    let file = event.target.files[0];
    let reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = function () {
      //me.modelvalue = reader.result;
      console.log(reader.result);
   this.imageValue=reader.result;
   localStorage.setItem("selectedImage",this.imageValue.toString());

    };
    reader.onerror = function (error) {
      console.log('Error: ', error);
    }
  }

  submit() {
    if (this.form.valid) {
      this.imageValue=localStorage.getItem("selectedImage");
        this.form.value.image=this.imageValue;
        this.save.emit(this.form.value);


    }

  }

}
