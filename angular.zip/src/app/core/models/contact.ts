export interface Contact {
  id?: number;
  firstname: string;
  lastname:string;
  email: string;
  image: string;
}
