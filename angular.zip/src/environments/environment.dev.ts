export const environment = {
  production: true,
  appApi: {
    baseUrl: 'https://reqres.in/api/users'
  },
  socketConfig: {
    url: 'https://reqres.in/api/users',
    opts: {
      transports: ['websocket']
    }
  }
};
